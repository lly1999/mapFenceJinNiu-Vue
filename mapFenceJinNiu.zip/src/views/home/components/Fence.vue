<template>
<!-- <el-descriptions
    title="围栏信息"
    direction="vertical"
    :column="4"
    :size="size"
    border
  >
    <el-descriptions-item label="Username">kooriookami</el-descriptions-item>
    <el-descriptions-item label="Telephone">18100000000</el-descriptions-item>
    <el-descriptions-item label="Place" :span="2">Suzhou</el-descriptions-item>
    <el-descriptions-item label="Remarks">
      <el-tag size="small">School</el-tag>
    </el-descriptions-item>
    <el-descriptions-item label="Address"
      >No.1188, Wuzhong Avenue, Wuzhong District, Suzhou, Jiangsu Province
    </el-descriptions-item>
  </el-descriptions> -->

    <el-skeleton 
        :loading="loading" 
        animated>
        <template #default>
            <template v-for="tableItem in tableData">
                <el-table :data="tableItem.data" class="table" :fit="false" max-height="300px">
                <el-table-column type="selection" width="55" />
                    <el-table-column 
                        v-for="i in tableItem.headerNames.length"
                        :label="tableItem.headerNames[i - 1]"
                        :prop="tableItem.dataNames[i - 1]" width="200"/>
                    <el-table-column label="操作" width="200">
        <template #default="scope">           
       <el-button
       link
          size="mini"
          type="primary"
          @click="showFence(scope.$index)" >查看</el-button>  
                       
      <el-button
          size="mini"
          type="primary"
          @click.prevent="inEditFence(scope.$index)" plain text>编辑</el-button>
          <el-button 
          size="mini"
          type="danger"
          @click="deleteFence(scope.$index,scope.row)" text>删除</el-button>
          </template>
    </el-table-column>
    
                </el-table>
            </template>
        </template>
    </el-skeleton>
    <div class="toolbar">
    <el-button @click="addFence()" type="primary">
      以当前点生成围栏
        </el-button>
        <el-button @click="previewFence()" type="primary">
      预览围栏
        </el-button> 
        <el-button @click="deleteMarker()" type="primary">
      清空点标记
        </el-button> 
        <el-button @click="editFence()" type="primary">
      确认编辑
        </el-button> 
        <el-button @click="exitEdit()" type="primary">
      退出编辑状态
        </el-button> 
  </div>
    <el-amap
    
      :center="polygon.center"
      :zoom="polygon.zoom"
      strokeStyle= 'dashed'
      :doubleClickZoom="polygon.doubleClickZoom"
      @init="init">
      <el-amap-control-geolocation
        
        :zoomToAccuracy="false"
        @complete="getLocation"
        position="LT"
      />
      <!-- 初始定位点 -->
     
      <!-- 嵌套信息窗体 -->
      <el-amap-info-window
        v-model:visible="visible"
        :position="polyPosition"
        anchor ="top-right"
        direction="vertical"
      >
        <el-descriptions title="围栏信息" border direction="vertical">
    <el-descriptions-item label="围栏名称">金牛区围栏 </el-descriptions-item>
    <el-descriptions-item label="创建者">吴教授</el-descriptions-item>
    <el-descriptions-item label="手机号">13908173345</el-descriptions-item>
    <el-descriptions-item label="微信号">W-estc-4223</el-descriptions-item>
    <el-descriptions-item label="状态">
      <el-tag size="small">使用中/暂停使用</el-tag>
    </el-descriptions-item>
</el-descriptions>
      </el-amap-info-window>
<!-- <el-amap-info-window
        v-model:visible="visibleFence"
        :position="polyPosition"
        anchor ="top-right"
        direction="vertical"
      >
        <el-descriptions title="围栏信息" border direction="vertical">
    <el-descriptions-item label="围栏名称">金牛区围栏 </el-descriptions-item>
    <el-descriptions-item label="创建者">吴教授</el-descriptions-item>
    <el-descriptions-item label="手机号">18100000000</el-descriptions-item>
    <el-descriptions-item label="微信号">18100000000</el-descriptions-item>
    <el-descriptions-item label="状态">
      <el-tag size="small">使用中/暂停使用</el-tag>
    </el-descriptions-item>
</el-descriptions>
      </el-amap-info-window> -->
      <!-- 多边形绘制 -->
       <el-amap-polygon
       :draggable="polygon.draggable"
        :path="polygon.path"
        :editable="polygon.edit"
        
        fillColor="ccebc5"
        strokeColor="#DC143C"
        bubble="true"
      >
      
      
      </el-amap-polygon>

       <!-- <el-amap-polygon
      
        :path="tableData.value[0].data[1].pointList"
        
        bubble="true"
        :fillColor="color[1]"
        strokeColor="#DC143C"
      ></el-amap-polygon>  -->
      <el-amap-info-window v-for="(window,index) in windowList"
:position="window.position"
v-model:visible="window.visible"
anchor="top-left"
> 
<div><el-descriptions title="人员信息" border direction="vertical">
    <el-descriptions-item label="姓名">{{window.personName }}</el-descriptions-item>
    <el-descriptions-item label="电话"><el-button plain type="primary" link><el-icon :size="25" style="vertical-align: middle"><PhoneFilled /></el-icon></el-button>{{window.tel}}</el-descriptions-item>
    <el-descriptions-item label="微信"><el-button plain type="primary" link><el-image class="logo-icon" :src="require('@/assets/home/icon32_wx_logo.png')" :size="25"></el-image></el-button>{{window.vx}}</el-descriptions-item>
    <el-descriptions-item label="街道">{{window.street}}</el-descriptions-item>
    <el-descriptions-item label="职务">{{window.title}}</el-descriptions-item>

    <el-descriptions-item label="状态">
      <el-tag size="small">执勤中</el-tag>
    </el-descriptions-item>
</el-descriptions></div>
</el-amap-info-window>
<el-amap-info-window v-for="(window,index) in windowFenceList"
:position="window.position"
v-model:visible="window.visible"
anchor="top-left"
> 
<div><el-descriptions title="围栏信息" border direction="vertical">
    <el-descriptions-item label="围栏名称">{{window.name }}</el-descriptions-item>
    <el-descriptions-item label="创建者">{{window.creator }}</el-descriptions-item>

    <el-descriptions-item label="创建时间">{{window.createTime}}</el-descriptions-item>
    <el-descriptions-item label="创建时间">待获取</el-descriptions-item>

    <el-descriptions-item label="状态">
  <el-tag size="small">{{window.status}}</el-tag>
    </el-descriptions-item>
</el-descriptions></div>
</el-amap-info-window>
      </el-amap>

      <el-dialog v-model="dialogFormVisible" title="请输入围栏信息" close-on-click-modal="false" close-on-press-escape="false">
        <el-form :model="form" label-width="120px" style="max-width: 500px">
    <el-form-item label="围栏名称" width="100px">
      <el-input v-model="fence.name" />
    </el-form-item>
    <el-form-item label="围栏编号" width="100px">
      <el-input v-model="fence.id" />
      </el-form-item>
      <el-form-item label="创建者" >
      <el-input v-model="fence.creator" />
    </el-form-item>
    <el-form-item label="创建时间" >
      <el-input v-model="fence.createTime" />
    </el-form-item>
    
   
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="cancelAddFence()">取消</el-button>

        <el-button type="primary" @click="confirmAddFence()"
          >确认</el-button
        >
      </span>
    </template>
  </el-dialog>
  
  <el-dialog v-model="dialogEditFormVisible" title="编辑围栏信息" close-on-click-modal="false" close-on-press-escape="false">
        <el-form :model="form" label-width="120px" style="max-width: 500px">
    <el-form-item label="编辑围栏名称" width="100px">
      <el-input v-model="fence.name" />
    </el-form-item>
      <el-form-item label="编辑创建者" >
      <el-input v-model="fence.creator" />
    </el-form-item>
    
    
   
    </el-form>
    <template #footer>
      <span class="dialog-footer">
        <el-button @click="cancelAddFence()">取消</el-button>

        <el-button type="primary" @click="confirmEditFence()"
          >确认</el-button
        >
      </span>
    </template>
  </el-dialog>

        


</template>

<script setup>
import { onBeforeMount, ref,getCurrentInstance,h,reactive,onMounted} from 'vue';
import { getFence, getFenceList,createFence,deleteFenceById,updateFenceById } from '@/api/home.js';
import { ElMessageBox,ElMessage } from 'element-plus'
import { before, countBy } from 'lodash';
import { SelectProps } from 'element-plus/es/components/select-v2/src/defaults';
onBeforeMount(() => {
    getFenceList().then(data => {
        tableData.value = data
        let tableItems =tableData.value[0].data
       // console.log(tableData.value[0].data[1].pointList)
       


    }).finally(() => {
        loading.value = false
      })
  })
  const polygonId = ref()
const polyPosition = [104.07740358713781, 30.707356042874134];
const dialogFormVisible=ref(false)
const tableVisible_yingmenkou = ref(false)
const isEdit=ref(false)
var pointPreview=[]
var polygonList = []
let map = null;
var pointList = []
var windowFenceList=[]
const dialogEditFormVisible=ref(false)
var markerList=[]
var markerLists=[]
var count =0
const visible=ref(false)
const dialogTableVisible = ref(false)
const loading = ref(true)
const tableData = ref([])
const color=["#0000FF","#008000","#FFFF00","	#FFA500","#1E90FF","#FF8C00","#FFFF00","#FFC0CB","#800080","#6A5ACD"]
const time = getTime(new Date())

function showFence(index){
  if (index==0)
visible.value=!visible.value
else{
  
  let windowFence = windowFenceList[index-1] //金牛区围栏不算，i-1
  
      windowFence.visible=!windowFence.visible 
      visible.value=!visible.value
      map.setCenter(windowFence.position)
}
  
  // var content = "围栏编号<br><br>围栏创建者：吴教授"+"<br>手机号：1838102132"+"<br>微信号：12312312123";
  // var position = [104.08740358713781, 30.717356042874134];
  // const window = new AMap.InfoWindow({
  // position:position,
  // anchor:"top-right"
  // });
  // window.setContent(content)
  // window.open(map);

  
}
function confirmEditFence(){
  dialogEditFormVisible.value=false
  ElMessage({
    message: h('p', null, [
      h('span', null, '编辑成功！'),
    ]),
    type:'success'
  })
  markerLists.push(markerList)
  for(let i=0;i<markerList.length;i++){
    markerLists[count][i].setDraggable(false)
    pointPreview[i] = [markerLists[count][i].getPosition().lng,markerLists[count][i].getPosition().lat ]
    
  }
  
  console.log(fence.id)
  fence.pointList=JSON.stringify(pointPreview)
  if (0<=fence.id<9){
      
      let polygon = new AMap.Polygon({
          path: pointPreview,
          fillColor: color[fence.id*1],
          strokeOpacity: 1,
          fillOpacity: 0.5,
          strokeColor: '#2b8cbe',
          strokeWeight: 1,
          strokeStyle: 'dashed',
          strokeDasharray: [5, 5],
          })
          map.add(polygon)
          pointPreview.splice(0,pointPreview.length)
          map.remove(markerList)
}
else{
  let polygon = new AMap.Polygon({
          path: pointPreview,
          fillColor: color[5],
          strokeOpacity: 1,
          fillOpacity: 0.5,
          strokeColor: '#2b8cbe',
          strokeWeight: 1,
          strokeStyle: 'dashed',
          strokeDasharray: [5, 5],
          })
          map.add(polygon)
          pointPreview.splice(0,pointPreview.length)
          map.remove(markerList)
}
updateFenceById(fence)
}


  function getTime(date) {
    let y = date.getFullYear() //年
    let m = date.getMonth() + 1  //月，月是从0开始的所以+1
    let d = date.getDate() //日
    m = m < 10 ? "0" + m : m //小于10补0
    d = d < 10 ? "0" + d : d //小于10补0
    return y + "-" + m + "-" + d; //返回时间形式yyyy-mm-dd
  }; 
  
  const fence = reactive({
    name:'',
    id:' ',
    creator:'吴教授',
    createTime:time,
    pointList:'',
    
  })
function previewFence(){
  markerLists.push(markerList)
  for(let i=0;i<markerList.length;i++){
    
    pointPreview[i] = [markerLists[count][i].getPosition().lng,markerLists[count][i].getPosition().lat ]
    
  }
  let polygon = new AMap.Polygon({
          path: pointPreview,
          fillColor: color[1],
          strokeOpacity: 1,
          fillOpacity: 0.5,
          strokeColor: '#2b8cbe',
          strokeWeight: 1,
          strokeStyle: 'dashed',
          strokeDasharray: [5, 5],
          })
          map.add(polygon)
          
          
          setInterval(function(){polygon.setOptions({
        fillOpacity: 0.7,
        fillColor: 'yellow'
      })
      setTimeout(() => {
        polygon.setOptions({
        fillOpacity: 0.7,
        fillColor: 'green'
      })
      }, 400);
      setTimeout(() => {
        polygon.remove()
      }, 3000);
    
    },800)
    
    
      
}
function exitEdit()
{
  if(isEdit.value==false){
    ElMessage({
    message: h('p', null, [
      h('span', null, '未在编辑状态！'),
    ]),
    type:'error'
  })
  }
  else{
    ElMessage({
    message: h('p', null, [
      h('span', null, '退出编辑状态！'),
    ]),
    type:'success'
  })
    map.add(polygonList)
    pointList.splice(0,pointList.length)
    map.remove(markerList)
    markerList.splice(0,markerList.length)
    pointPreview.splice(0,pointPreview.length)
  }
  isEdit.value=false
}
function editFence(polygonId)

{
  if(isEdit.value==false){
    ElMessage({
    message: h('p', null, [
      h('span', null, '未在编辑状态！'),
    ]),
    type:'error'
  })
  }
  
else{
  dialogEditFormVisible.value=true
  
}


  //updateFence(polygonId)
}
function inEditFence(index){
  //dialogEditFormVisible.value=true
  if (index==0){
    ElMessage({
    message: h('p', null, [
      h('span', null, '金牛区默认围栏，不可编辑 '),
    ]),
    type:'error'
  })
  }

  
  else{
    if(isEdit.value==true){
      ElMessage({
    message: h('p', null, [
      h('span', null, '已经在编辑状态！ '),
    ]),
    type:'error'
  })
    }
    else{
      isEdit.value=true
polygonId.value = index
    pointList=polygonList[index-1].getPath()
  
  ElMessage({
    message: h('p', null, [
      h('span', null, '进入编辑状态！ '),
    ]),
    type:'success'
  })
  for(let i =0;i<pointList.length;i++)
  { 
    let markerEdit=[pointList[i].lng,pointList[i].lat]
    const marker1 = new AMap.Marker({
    position:markerEdit,
    draggable:true
    
  })

    markerList.push(marker1)
map.add(marker1)
  }
  
  polygonList[index-1].remove()
  fence.name=windowFenceList[polygonId.value-1].name
  fence.id=windowFenceList[polygonId.value-1].id
  console.log(fence)
}
    
}
  
  
}
const init = (e) => {
  // const marker = new AMap.Marker({
  //   position: [104.05740358713781, 30.697356042874134],
  // },
  // );
  // e.add(marker);
  map = e;
 
  var clickHandler = function(e) {
    let arr=[e.lnglat.getLng(),e.lnglat.getLat()]
    ElMessage({
    message: h('p', null, [
      h('span', null, '您在 '+e.lnglat.getLng() +" "+ e.lnglat.getLat()+"新建点成功"),
    ]),
    type:'success'
  })
  


  //alert('您在[ '+e.lnglat.getLng()+','+e.lnglat.getLat()+' ]的位置点击了地图！');
  const marker1 = new AMap.Marker({
    position:[e.lnglat.getLng(),e.lnglat.getLat()],
    draggable:true
    
  })
  marker1.on('dbclick',marker1.remove())
  markerList.push(marker1)
  
  map.add(marker1)
  
  
  pointPreview.push(arr)
  
};

  
// 绑定事件
map.on('dblclick', clickHandler);

getFenceList().then(data => {
        tableData.value = data
        let tableItems =tableData.value[0].data 
  for(let i=0;i<tableItems.length;i++){
    
    if (tableItems[i].pointList!=0)
    
    //后端获取到的pointlist为字符串"[[101,32],a [12,132]]"，这里要将其转换为二维数组形式[[101,32],[12,132]],这样多边形才能获成功创建，加上a是为了方便split函数分割处理",a",有相同的", "
          { 
            let path =  tableItems[i].pointList.substr(1)
            path = path.slice(0,path.length-1) //上面两步将 "[[101,32],a [12,132]]" 转换为"[101,32],a [12,132]"，去掉外层[]
            for(let i =0;i<path.split(",a").length;i++) //for循环,首先将数据按",a"分割为[['[101,32]'],'[12,132]'],的数组，此步内部仍然为字符串，使用for循环按个访问外部数组的每个元素
            {
              let pathLng = path.split(",a")[i].replace("[","").replace("]","").split(", ")[0]*1//此步将'[101,32]'的101转换为number类型
            let pathLat = path.split(",a")[i].replace("[","").replace("]","").split(", ")[1]*1 //此步将'[101,32]'的32转换为number类型
            let point =[pathLng,pathLat] //再将number类型存在数组中
            pointList.push(point)//新开一个pointList存储这些数组，转换为[[101,32]]的二维数组
            
            }
            let windowFence = {
              position:pointList[i],
              visible:false,
              name:tableItems[i].val0,
              id:tableItems[i].val1,
              creator:tableItems[i].val2,
              createTime:tableItems[i].val3,
              
              status:'使用中'
            }
            windowFenceList.push(windowFence)
          const polygonCenter = pointList[3]
            let polygon = new AMap.Polygon({
          path: pointList,
          fillColor: color[i],
          strokeOpacity: 1,
          fillOpacity: 0.5,
          strokeColor: '#2b8cbe',
          strokeWeight: 1,
          strokeStyle: 'dashed',
          strokeDasharray: [5, 5],
          });
            polygon.on('click', () => {
              //visible.value=!visible.value
      let windowFence = windowFenceList[i-1] //金牛区围栏不算，i-1
      windowFence.visible=!windowFence.visible
      
      

  //     var info = [];
  //       info.push("<div style=\"padding:7px 0px 0px 0px;\"><h4>"+  tableItems[i].val0+"</h4>" );
  //       info.push("<p class='input-item'>id :"+tableItems[i].val1+"</p></div></div>");
  //       info.push("<p class='input-item'>创建者 : "+ tableItems[i].val2+"</p>");
  //       info.push("<p class='input-item'>创建时间 :"+tableItems[i].val3+"</p></div></div>");
        

  
  //  const infoWindow = new AMap.InfoWindow({
  //    position:polygonCenter,
  //    content: info.join(""),
  //    anchor:"top-right"
    
  //  })
  //  infoWindow.open(map, polygonCenter);
    })

          polygonList.push(polygon)
          map.add(polygon)
          
          pointList.splice(0,pointList.length)
          }
      }
})

}

const deleteRow = (index) => {
    const tableItem = tableData.value;
    console.log(tableItem[0].data)
  tableItem[0].data.splice(index, 1)
}

function confirmAddFence(){
    dialogFormVisible.value = false
ElMessage({
    message: h('p', null, [
      h('span', null, '添加成功！'),
    ]),
    type:'success'
  })
  markerLists.push(markerList)
  for(let i=0;i<markerList.length;i++){
    markerLists[count][i].setDraggable(false)
    pointPreview[i] = [markerLists[count][i].getPosition().lng,markerLists[count][i].getPosition().lat ]
    
  }

    fence.pointList=JSON.stringify(pointPreview)
    
     const tableItem = tableData.value;
     
     let addItem={
      val0:fence.name,
      val1:fence.id,
      val2:fence.creator,
      val3:fence.createTime,
     }
     
     tableItem[0].data.push(addItem)
     
     createFence(fence)
     
    markerList.splice(0,markerList.length)
    
    if (0<=fence.id<9){
      
      let polygon = new AMap.Polygon({
          path: pointPreview,
          fillColor: color[fence.id*1],
          strokeOpacity: 1,
          fillOpacity: 0.5,
          strokeColor: '#2b8cbe',
          strokeWeight: 1,
          strokeStyle: 'dashed',
          strokeDasharray: [5, 5],
          })
          map.add(polygon)
          pointPreview.splice(0,pointPreview.length)
          map.remove(markerList)
}
else{
  let polygon = new AMap.Polygon({
          path: pointPreview,
          fillColor: color[5],
          strokeOpacity: 1,
          fillOpacity: 0.5,
          strokeColor: '#2b8cbe',
          strokeWeight: 1,
          strokeStyle: 'dashed',
          strokeDasharray: [5, 5],
          })
          map.add(polygon)
          pointPreview.splice(0,pointPreview.length)
          map.remove(markerList)
}

}
    

function cancelAddFence(){
    dialogFormVisible.value = false
ElMessage({
    message: h('p', null, [
      h('span', null, '取消添加围栏！'),
    ]),
    type:'error'
  })
  map.remove(polygon)
}

function deleteMarker(){
    pointList.splice(0,pointList.length)
    map.remove(markerList)
    markerList.splice(0,markerList.length)
    pointPreview.splice(0,pointPreview.length)
    
    
}
function addFence(){
    dialogFormVisible.value = true 
    
}
function deleteFence(index,fenceId){
  
   ElMessageBox({
        title: '提示', //MessageBox 标题
        message: '您的权限是管理员，是否确定删除当前项?', //MessageBox 消息正文内容
        confirmButtonText: '确定', //确定按钮的文本内容
        cancelButtonText: '取消', //取消按钮的文本内容
        showCancelButton: true, //是否显示取消按钮
        closeOnClickModal: false, //是否可通过点击遮罩关闭
        type: 'warning', //消息类型，用于显示图标
    }).then(() => {
const tableItem = tableData.value;
    
  tableItem[0].data.splice(index, 1)
  
  pointList.splice(0,pointList.length)
   
  map.remove(markerList)
  map.remove(polygonList[index-1]) //因为固定围栏金牛区，所以index-1与polygon对应
  markerList.splice(0,markerList.length)
  polygonList.splice(index,1)
  deleteFenceById(fenceId.val1)  //根据id删除
        ElMessage.success('删除成功!');
    }).catch(() => {
        ElMessage.info('已取消删除!');
    });
    
    
}








const polygon=ref({
    strokeStyle: 'dashed',
    doubleClickZoom:false,
        zoom:13.5,
        draggable: false,
        visible: true,
        edit: false,
        position : [104.05740358713781, 30.697356042874134],
        center : ([104.04396204, 30.71499549]),
        path: [[[[103.954281,30.776256],[103.953423,30.777288],[103.951749,30.779187],[103.95337,30.780195],[103.955097,30.78127],[103.956642,30.77939],[103.957092,30.778791],[103.95838,30.777288],[103.957886,30.776984],[103.956255,30.775951],[103.955826,30.775647],[103.955655,30.775408],[103.954281,30.776256]]],[[[104.05802,30.678438],[104.057178,30.677989],[104.056894,30.677838],[104.056357,30.677441],[104.055853,30.676998],[104.055123,30.676398],[104.054909,30.676297],[104.054007,30.675891],[104.053557,30.675826],[104.05316,30.675697],[104.052922,30.675311],[104.052818,30.675174],[104.052799,30.675148],[104.052545,30.674812],[104.052466,30.67469],[104.052451,30.674627],[104.052447,30.674532],[104.052439,30.674484],[104.052439,30.67444],[104.052451,30.674396],[104.05252,30.67427],[104.052527,30.674229],[104.052515,30.67419],[104.052373,30.673925],[104.052065,30.673395],[104.051784,30.672913],[104.051628,30.672626],[104.05157,30.672497],[104.051516,30.672363],[104.05146,30.672188],[104.051359,30.671783],[104.051318,30.671659],[104.051291,30.671596],[104.051259,30.671542],[104.051174,30.67145],[104.05113,30.671374],[104.050951,30.671066],[104.050859,30.670906],[104.050827,30.670838],[104.050815,30.670772],[104.05082,30.670709],[104.0509,30.67044],[104.050913,30.67037],[104.050923,30.670278],[104.050923,30.669773],[104.050909,30.669701],[104.050904,30.669554],[104.050907,30.669392],[104.050904,30.668857],[104.050902,30.668363],[104.050851,30.668156],[104.05079,30.66797],[104.05071,30.66781],[104.050587,30.667682],[104.050524,30.667616],[104.050314,30.667407],[104.049869,30.666901],[104.048871,30.665793],[104.048858,30.665779],[104.048793,30.665707],[104.048598,30.665556],[104.04833,30.665385],[104.048062,30.665208],[104.047878,30.665058],[104.047753,30.664903],[104.046766,30.663086],[104.045055,30.663981],[104.044212,30.664414],[104.043098,30.665033],[104.042976,30.665101],[104.04199,30.6656],[104.041928,30.665655],[104.041293,30.665982],[104.041183,30.666006],[104.040849,30.666162],[104.040762,30.666206],[104.040608,30.666279],[104.040589,30.666288],[104.040463,30.666347],[104.040427,30.66636],[104.039802,30.666654],[104.039856,30.666744],[104.039856,30.666835],[104.039802,30.666944],[104.039665,30.667052],[104.038886,30.667337],[104.038483,30.66747],[104.038249,30.667596],[104.038054,30.667736],[104.037864,30.667925],[104.03728,30.668536],[104.03691,30.66888],[104.036656,30.669049],[104.036418,30.669131],[104.036184,30.66915],[104.036013,30.66912],[104.035814,30.669042],[104.035497,30.668934],[104.035249,30.66889],[104.034944,30.668887],[104.034686,30.668955],[104.034462,30.66907],[104.034267,30.669245],[104.033931,30.669744],[104.033692,30.670254],[104.03349,30.670528],[104.033154,30.67092],[104.032855,30.671243],[104.032718,30.671388],[104.032644,30.671467],[104.032421,30.671716],[104.032292,30.671956],[104.032271,30.672325],[104.03226,30.67251],[104.032346,30.672786],[104.032442,30.673174],[104.032516,30.673516],[104.032784,30.673537],[104.032898,30.67363],[104.032929,30.673805],[104.032867,30.67401],[104.032681,30.674225],[104.032331,30.674461],[104.032077,30.674899],[104.031952,30.675128],[104.031755,30.675489],[104.031278,30.676468],[104.031334,30.676667],[104.031351,30.676775],[104.031359,30.676966],[104.031444,30.677472],[104.031481,30.677691],[104.031568,30.677982],[104.031644,30.678111],[104.031766,30.678204],[104.031965,30.678326],[104.032565,30.678619],[104.032677,30.678731],[104.032725,30.678891],[104.032735,30.67911],[104.032686,30.67929],[104.032555,30.679469],[104.032389,30.6796],[104.03218,30.679667],[104.031995,30.679686],[104.03082,30.679664],[104.030587,30.679683],[104.030411,30.679721],[104.030221,30.679822],[104.029868,30.680096],[104.029167,30.680728],[104.029149,30.680739],[104.029137,30.680756],[104.029103,30.680787],[104.029069,30.680818],[104.028955,30.68092],[104.02866,30.681186],[104.028396,30.681379],[104.028099,30.681495],[104.027792,30.681567],[104.027485,30.681591],[104.027225,30.681519],[104.02702,30.681407],[104.026786,30.681222],[104.026596,30.681129],[104.026411,30.68109],[104.026182,30.681108],[104.025924,30.681195],[104.025724,30.681297],[104.025573,30.681423],[104.024852,30.682402],[104.024834,30.682417],[104.024827,30.682424],[104.024688,30.682545],[104.024513,30.682641],[104.023572,30.682916],[104.023231,30.682968],[104.022934,30.682967],[104.022656,30.682933],[104.022303,30.68289],[104.021996,30.682909],[104.021767,30.682947],[104.021622,30.683006],[104.021589,30.683019],[104.021441,30.683112],[104.020912,30.683476],[104.020709,30.683579],[104.020535,30.683643],[104.020349,30.683665],[104.020186,30.683653],[104.01989,30.683589],[104.019361,30.683431],[104.019007,30.683296],[104.018664,30.683104],[104.018373,30.682921],[104.018141,30.682698],[104.017786,30.682285],[104.017742,30.682284],[104.017756,30.68225],[104.017704,30.68223],[104.017634,30.682226],[104.017582,30.682232],[104.017495,30.68226],[104.016455,30.68238],[104.016321,30.682419],[104.016257,30.682437],[104.016184,30.682459],[104.016169,30.682463],[104.016136,30.682473],[104.016367,30.68292],[104.014205,30.683908],[104.012408,30.684729],[104.011764,30.685024],[104.011527,30.684617],[104.011412,30.68442],[104.011165,30.683995],[104.010727,30.684793],[104.010648,30.684953],[104.010613,30.685104],[104.010599,30.685445],[104.010586,30.685568],[104.010508,30.68568],[104.010176,30.685933],[104.010011,30.685978],[104.009802,30.685995],[104.00923,30.685932],[104.008989,30.685939],[104.008415,30.686084],[104.008251,30.686101],[104.008108,30.686053],[104.007469,30.685734],[104.006424,30.685726],[104.005018,30.685707],[104.004263,30.685995],[104.004047,30.686081],[104.00371,30.686216],[104.003598,30.686445],[104.003603,30.686798],[104.003657,30.687173],[104.003659,30.687195],[104.003698,30.687561],[104.004463,30.688168],[104.006663,30.687193],[104.007341,30.686892],[104.007717,30.687418],[104.00708,30.687679],[104.006183,30.688046],[104.006494,30.688712],[104.008456,30.688733],[104.008533,30.688741],[104.00861,30.68875],[104.008682,30.688735],[104.008798,30.688766],[104.008833,30.688775],[104.011,30.687711],[104.011018,30.687702],[104.011428,30.688366],[104.01147,30.688434],[104.01193,30.689178],[104.011005,30.689711],[104.01062,30.689932],[104.010614,30.689917],[104.009923,30.690349],[104.008085,30.691393],[104.006254,30.692434],[104.007327,30.694685],[104.009086,30.693412],[104.009672,30.693994],[104.008654,30.694787],[104.008123,30.695903],[104.008507,30.696327],[104.008578,30.69642],[104.008868,30.696784],[104.009236,30.697249],[104.009035,30.69751],[104.008679,30.697967],[104.008756,30.698084],[104.00905,30.698527],[104.009044,30.69905],[104.008148,30.699467],[104.008094,30.699492],[104.007868,30.699598],[104.007795,30.699597],[104.007783,30.699597],[104.007625,30.699602],[104.007545,30.699594],[104.007513,30.699613],[104.007489,30.699593],[104.007389,30.699592],[104.007261,30.699591],[104.00677,30.699651],[104.006089,30.699733],[104.005751,30.699696],[104.005021,30.699645],[104.004378,30.699073],[104.003992,30.698677],[104.00367,30.698326],[104.003489,30.698052],[104.002681,30.697898],[104.001116,30.69818],[104.000234,30.699591],[103.999721,30.701119],[103.99916,30.702792],[103.999516,30.703632],[103.999162,30.703761],[103.998068,30.704591],[103.997489,30.704121],[103.996437,30.703407],[103.996237,30.703412],[103.995684,30.703427],[103.994229,30.703579],[103.989927,30.70403],[103.98952,30.704675],[103.988941,30.705506],[103.988576,30.705819],[103.9879,30.705266],[103.988126,30.704887],[103.988812,30.70438],[103.989188,30.704196],[103.989606,30.703809],[103.989511,30.703725],[103.989515,30.703717],[103.989505,30.703416],[103.989345,30.703216],[103.98759,30.701828],[103.986727,30.701146],[103.986515,30.700773],[103.986505,30.700517],[103.986615,30.700325],[103.986811,30.700233],[103.9871,30.700219],[103.98868,30.700518],[103.988982,30.700567],[103.989259,30.700536],[103.98955,30.700387],[103.989681,30.700186],[103.989851,30.698691],[103.989733,30.698371],[103.989467,30.698008],[103.989254,30.697838],[103.989148,30.697651],[103.989129,30.697454],[103.989422,30.696471],[103.989531,30.696326],[103.989689,30.696215],[103.989918,30.696104],[103.990161,30.696078],[103.990779,30.696213],[103.991001,30.69625],[103.99119,30.696199],[103.991339,30.696028],[103.99139,30.695744],[103.991268,30.694885],[103.989698,30.695144],[103.987719,30.693628],[103.984692,30.692849],[103.980706,30.692811],[103.98053,30.693123],[103.980259,30.69347],[103.978711,30.695341],[103.978493,30.69555],[103.978291,30.695675],[103.976528,30.696472],[103.97617,30.696701],[103.975971,30.696879],[103.975887,30.697046],[103.975834,30.697276],[103.975813,30.69759],[103.97575,30.697747],[103.975572,30.697998],[103.975372,30.698207],[103.975173,30.698332],[103.974837,30.698467],[103.973849,30.698769],[103.97345,30.698925],[103.973272,30.699102],[103.973146,30.699385],[103.973083,30.699751],[103.973083,30.700034],[103.973125,30.700264],[103.973329,30.700626],[103.97396,30.701413],[103.974096,30.701676],[103.974138,30.701969],[103.974086,30.702555],[103.97397,30.702859],[103.973708,30.703172],[103.973403,30.703444],[103.973256,30.703642],[103.973225,30.70382],[103.973288,30.703998],[103.973771,30.704544],[103.973839,30.704728],[103.973807,30.704969],[103.973681,30.705115],[103.973408,30.70524],[103.973104,30.705323],[103.972831,30.705333],[103.972579,30.705269],[103.972085,30.705016],[103.971822,30.704974],[103.971591,30.704973],[103.971423,30.705046],[103.971255,30.705224],[103.971171,30.705422],[103.97115,30.705632],[103.971129,30.706543],[103.97115,30.706753],[103.971203,30.706889],[103.971423,30.707298],[103.971502,30.707586],[103.971565,30.707921],[103.971565,30.708204],[103.971523,30.708455],[103.971418,30.708707],[103.971156,30.709125],[103.971072,30.709355],[103.971019,30.709627],[103.970998,30.710434],[103.970893,30.710706],[103.970725,30.710957],[103.970494,30.711144],[103.970137,30.71129],[103.969643,30.711341],[103.969013,30.71134],[103.967711,30.711389],[103.966798,30.711439],[103.966262,30.7115],[103.965816,30.711588],[103.964923,30.711837],[103.964629,30.711878],[103.964251,30.711877],[103.963863,30.711793],[103.962928,30.711372],[103.962603,30.711276],[103.96233,30.711255],[103.961868,30.711296],[103.9617,30.711369],[103.961616,30.711546],[103.961605,30.711766],[103.961647,30.712039],[103.962018,30.713284],[103.961647,30.714054],[103.961544,30.714268],[103.961758,30.714479],[103.961327,30.715164],[103.960708,30.716011],[103.960519,30.716157],[103.960309,30.716199],[103.960067,30.716177],[103.959626,30.716103],[103.959375,30.716113],[103.959133,30.716196],[103.957989,30.716791],[103.957737,30.716884],[103.957464,30.716915],[103.957264,30.716873],[103.957086,30.716747],[103.956404,30.716064],[103.956094,30.715901],[103.955727,30.715838],[103.95538,30.715858],[103.955013,30.715951],[103.954583,30.716139],[103.954215,30.716379],[103.953974,30.716598],[103.953816,30.716797],[103.953753,30.716996],[103.953743,30.717258],[103.954084,30.719264],[103.954189,30.719526],[103.954325,30.719705],[103.95485,30.720208],[103.955008,30.720418],[103.95506,30.720596],[103.954997,30.720753],[103.95485,30.720892],[103.955367,30.720942],[103.956408,30.721537],[103.956453,30.721563],[103.956511,30.721556],[103.956672,30.721574],[103.956974,30.72167],[103.958499,30.722193],[103.960352,30.721764],[103.960907,30.721743],[103.961214,30.721906],[103.961365,30.722173],[103.961422,30.722599],[103.961105,30.723366],[103.961252,30.724032],[103.961835,30.724357],[103.962106,30.724944],[103.962312,30.72585],[103.962555,30.726171],[103.964334,30.726816],[103.964351,30.726838],[103.964405,30.726842],[103.965372,30.727192],[103.965726,30.726936],[103.966184,30.726357],[103.966302,30.725872],[103.966224,30.725365],[103.966022,30.724758],[103.965992,30.724668],[103.966231,30.72272],[103.966308,30.722552],[103.96641,30.722449],[103.966815,30.722314],[103.966923,30.722262],[103.967263,30.721883],[103.9674,30.721769],[103.967562,30.721695],[103.96798,30.721676],[103.968148,30.721701],[103.96831,30.721679],[103.968439,30.721565],[103.968679,30.721167],[103.968774,30.721017],[103.968945,30.720886],[103.968955,30.720882],[103.969308,30.721072],[103.969354,30.721141],[103.969342,30.721234],[103.969122,30.721406],[103.969064,30.721533],[103.969076,30.722134],[103.969146,30.722261],[103.969365,30.722481],[103.969458,30.722504],[103.969713,30.722401],[103.969904,30.722441],[103.970013,30.72243],[103.970104,30.722367],[103.970199,30.721859],[103.970176,30.721709],[103.970072,30.721582],[103.970002,30.721409],[103.969967,30.721155],[103.969985,30.720524],[103.970216,30.720389],[103.97091,30.719688],[103.971066,30.719521],[103.971158,30.719462],[103.971225,30.719418],[103.971773,30.719234],[103.973361,30.718763],[103.97409,30.718505],[103.974444,30.718053],[103.974637,30.717564],[103.974541,30.717269],[103.974337,30.717066],[103.974122,30.717011],[103.973007,30.716974],[103.972803,30.716909],[103.972599,30.716707],[103.972513,30.716393],[103.972609,30.716079],[103.972867,30.715821],[103.973253,30.715433],[103.973254,30.715064],[103.976644,30.715987],[103.980378,30.716999],[103.980592,30.717057],[103.984928,30.718421],[103.979435,30.724029],[103.975529,30.72794],[103.975605,30.727964],[103.976821,30.728349],[103.977607,30.728598],[103.979606,30.729231],[103.980379,30.729821],[103.980894,30.730227],[103.98128,30.730669],[103.979781,30.732521],[103.980279,30.732564],[103.981307,30.732506],[103.982178,30.732255],[103.983119,30.731682],[103.983981,30.731038],[103.986115,30.728584],[103.986882,30.728041],[103.988197,30.727548],[103.989669,30.727333],[103.990915,30.727371],[103.991874,30.727593],[103.992936,30.727998],[103.993642,30.728435],[103.994374,30.729171],[103.996265,30.732511],[103.996686,30.733049],[103.99674,30.733116],[103.996745,30.733124],[103.997267,30.733789],[103.99828,30.734795],[103.998291,30.734803],[103.9983,30.734814],[103.998731,30.735241],[104.000442,30.736654],[104.000586,30.736773],[104.001554,30.737808],[104.001763,30.738366],[104.001728,30.738942],[104.001449,30.739553],[104.000735,30.74023],[103.998853,30.741682],[103.99786,30.742797],[103.997049,30.744052],[103.996753,30.745325],[103.996562,30.746616],[103.996509,30.749111],[103.996567,30.749854],[103.99657,30.74987],[103.99657,30.749883],[103.996631,30.750675],[103.996901,30.751913],[103.997015,30.752439],[103.997651,30.754343],[103.998435,30.755793],[103.99863,30.756005],[103.999367,30.75681],[104.000753,30.757598],[104.002369,30.75802],[104.003933,30.758429],[104.008629,30.758927],[104.010363,30.758889],[104.011704,30.758482],[104.012741,30.757893],[104.013151,30.757561],[104.013556,30.757234],[104.013536,30.757106],[104.013583,30.756854],[104.013837,30.756444],[104.014209,30.756098],[104.014739,30.755744],[104.015246,30.755533],[104.01576,30.755384],[104.016038,30.755211],[104.01633,30.754889],[104.016702,30.754258],[104.016869,30.753817],[104.016861,30.753501],[104.016734,30.753201],[104.016386,30.752868],[104.016128,30.75269],[104.015978,30.752469],[104.015825,30.752135],[104.015273,30.750928],[104.015099,30.75073],[104.014838,30.750658],[104.013563,30.750504],[104.013262,30.750393],[104.013057,30.750187],[104.012962,30.74995],[104.012601,30.748966],[104.012578,30.748729],[104.012633,30.748556],[104.012815,30.748415],[104.016623,30.746871],[104.016983,30.746813],[104.017712,30.74687],[104.018131,30.746974],[104.018424,30.74718],[104.019794,30.748723],[104.020039,30.748834],[104.02034,30.748851],[104.020633,30.748781],[104.020934,30.748608],[104.021155,30.748356],[104.021306,30.747986],[104.021329,30.747654],[104.021269,30.747062],[104.021258,30.746952],[104.021068,30.746138],[104.021005,30.745483],[104.02102,30.745148],[104.021036,30.744796],[104.021074,30.744655],[104.021278,30.743901],[104.021278,30.743483],[104.021183,30.743064],[104.020763,30.741753],[104.020766,30.741401],[104.020934,30.741115],[104.021251,30.74084],[104.021736,30.740634],[104.022171,30.740596],[104.022557,30.740646],[104.022953,30.740825],[104.023982,30.741499],[104.024388,30.741668],[104.024853,30.741689],[104.025318,30.741503],[104.025684,30.741129],[104.025781,30.740993],[104.026164,30.740454],[104.02649,30.740169],[104.027578,30.739501],[104.027836,30.739216],[104.027925,30.738881],[104.027865,30.738575],[104.027588,30.738327],[104.027311,30.738287],[104.026836,30.738414],[104.026173,30.73859],[104.025827,30.738559],[104.02557,30.738411],[104.025461,30.738154],[104.02551,30.737947],[104.025653,30.737803],[104.026925,30.73653],[104.027178,30.736102],[104.027286,30.735727],[104.027652,30.734673],[104.027705,30.734579],[104.02788,30.734269],[104.028256,30.733885],[104.028648,30.733596],[104.029534,30.733149],[104.031422,30.732376],[104.032325,30.732081],[104.032859,30.731808],[104.032971,30.731781],[104.033205,30.731725],[104.033533,30.731795],[104.033881,30.73205],[104.034116,30.732409],[104.034238,30.732819],[104.034508,30.73432],[104.034682,30.734809],[104.035022,30.735229],[104.035405,30.735493],[104.036111,30.73579],[104.036389,30.736036],[104.036581,30.736447],[104.036746,30.737166],[104.036766,30.737555],[104.036772,30.737666],[104.036711,30.738048],[104.036546,30.73844],[104.036206,30.738893],[104.035266,30.739677],[104.034056,30.740425],[104.033638,30.74079],[104.032819,30.741778],[104.031269,30.744777],[104.031278,30.744959],[104.031426,30.745064],[104.035824,30.745592],[104.036075,30.745651],[104.03609,30.745654],[104.036372,30.74572],[104.036738,30.74592],[104.038367,30.747367],[104.038378,30.747373],[104.038391,30.747388],[104.039282,30.748179],[104.039676,30.748529],[104.039855,30.748688],[104.04117,30.749633],[104.041392,30.749753],[104.041427,30.749808],[104.041473,30.749797],[104.041608,30.74987],[104.041717,30.749929],[104.042763,30.750493],[104.043955,30.750882],[104.044213,30.750966],[104.04443,30.751037],[104.044445,30.751043],[104.04446,30.751047],[104.044581,30.751087],[104.044594,30.751092],[104.044608,30.751095],[104.04483,30.751168],[104.044841,30.751173],[104.044854,30.751176],[104.044992,30.751221],[104.04563,30.751365],[104.045647,30.751367],[104.045661,30.751372],[104.046812,30.751631],[104.04768,30.751985],[104.047844,30.752052],[104.048083,30.752149],[104.048579,30.75251],[104.050067,30.751258],[104.050611,30.751036],[104.050807,30.750956],[104.051416,30.750903],[104.051753,30.750936],[104.05478,30.749849],[104.056095,30.748736],[104.056869,30.748211],[104.058126,30.747358],[104.058938,30.746807],[104.060194,30.745955],[104.061647,30.744673],[104.06323,30.743449],[104.064881,30.742505],[104.066395,30.741562],[104.066577,30.741461],[104.066685,30.741402],[104.067009,30.740954],[104.067246,30.740521],[104.069162,30.740121],[104.069848,30.73997],[104.071126,30.739689],[104.0727,30.739536],[104.074068,30.740057],[104.075222,30.741479],[104.075357,30.74187],[104.075381,30.741876],[104.075382,30.74194],[104.075543,30.742168],[104.075946,30.742994],[104.07632,30.744245],[104.077233,30.749155],[104.07734,30.749423],[104.077807,30.750593],[104.078998,30.752131],[104.080536,30.753099],[104.081944,30.753589],[104.083038,30.753744],[104.083534,30.753814],[104.086081,30.753965],[104.086993,30.754138],[104.088027,30.754522],[104.0888,30.754909],[104.090518,30.755771],[104.09129,30.756159],[104.093992,30.757795],[104.095382,30.758935],[104.096378,30.760223],[104.096398,30.760249],[104.096583,30.76071],[104.096284,30.760826],[104.096141,30.760907],[104.096067,30.760938],[104.095965,30.760958],[104.09577,30.760991],[104.094909,30.761236],[104.094827,30.761282],[104.094733,30.761366],[104.094657,30.761485],[104.094605,30.761683],[104.094602,30.761968],[104.09472,30.763092],[104.094736,30.763136],[104.094769,30.763189],[104.095415,30.76378],[104.095621,30.763927],[104.095885,30.764075],[104.096804,30.764598],[104.096863,30.764648],[104.09689,30.764702],[104.096906,30.764814],[104.096858,30.76528],[104.096832,30.765359],[104.096608,30.765882],[104.096583,30.765914],[104.096523,30.765955],[104.095974,30.766179],[104.095915,30.766184],[104.095858,30.766178],[104.095729,30.766157],[104.095664,30.76613],[104.095573,30.76607],[104.094875,30.76549],[104.094812,30.765451],[104.094738,30.765422],[104.094644,30.765392],[104.094317,30.765369],[104.094242,30.76536],[104.094181,30.765342],[104.094071,30.765277],[104.09401,30.765245],[104.09394,30.76523],[104.093815,30.765229],[104.093521,30.765294],[104.093416,30.765305],[104.091822,30.765354],[104.091733,30.76535],[104.091652,30.765335],[104.090685,30.7652],[104.090318,30.765173],[104.089995,30.765217],[104.089629,30.765326],[104.089459,30.765464],[104.08935,30.765627],[104.089259,30.765871],[104.089258,30.766022],[104.089309,30.76628],[104.089433,30.766817],[104.089583,30.767063],[104.089607,30.767221],[104.089593,30.767337],[104.089517,30.767494],[104.089076,30.768291],[104.088392,30.768119],[104.087402,30.767969],[104.085716,30.767783],[104.084821,30.767596],[104.084048,30.767198],[104.083474,30.766678],[104.083014,30.765983],[104.082756,30.7654],[104.08259,30.765372],[104.081884,30.765229],[104.081622,30.765128],[104.0813,30.764933],[104.081018,30.764674],[104.080718,30.764305],[104.080579,30.764029],[104.080289,30.76317],[104.080236,30.762985],[104.080224,30.762856],[104.080232,30.762705],[104.080281,30.762559],[104.080508,30.762067],[104.080529,30.761989],[104.080533,30.76191],[104.080513,30.761828],[104.08046,30.761735],[104.080441,30.761676],[104.080441,30.761618],[104.080421,30.761574],[104.080323,30.761489],[104.079806,30.761181],[104.079712,30.761151],[104.079613,30.761145],[104.079492,30.761159],[104.079377,30.761204],[104.078637,30.761854],[104.078545,30.761897],[104.07843,30.761917],[104.078332,30.761928],[104.078245,30.761921],[104.078136,30.761891],[104.078022,30.761797],[104.077859,30.761594],[104.077762,30.761459],[104.077722,30.761435],[104.077648,30.761412],[104.077571,30.76137],[104.077534,30.761341],[104.077487,30.761265],[104.077407,30.761092],[104.077337,30.761022],[104.077229,30.760956],[104.077118,30.760926],[104.076976,30.760922],[104.076787,30.760967],[104.076531,30.761114],[104.076464,30.761143],[104.076393,30.761151],[104.076308,30.76113],[104.076017,30.761156],[104.075618,30.761276],[104.075516,30.761356],[104.07544,30.761484],[104.075395,30.76181],[104.075527,30.763724],[104.075499,30.7638],[104.075424,30.763869],[104.075308,30.763915],[104.074956,30.763947],[104.074754,30.763939],[104.074558,30.76388],[104.074403,30.763797],[104.074289,30.763703],[104.074209,30.763602],[104.074157,30.763427],[104.074071,30.763112],[104.073901,30.762527],[104.073872,30.762469],[104.073832,30.762417],[104.073789,30.762329],[104.073773,30.762224],[104.073759,30.761935],[104.073742,30.761862],[104.073713,30.76178],[104.07363,30.76166],[104.073442,30.761441],[104.073365,30.761376],[104.07315,30.761252],[104.073079,30.761225],[104.072938,30.761207],[104.072312,30.76121],[104.072227,30.761227],[104.072149,30.761264],[104.071877,30.761422],[104.071707,30.761582],[104.0716,30.761681],[104.071318,30.761877],[104.071176,30.761954],[104.070924,30.762058],[104.070727,30.762151],[104.070512,30.762272],[104.070264,30.762431],[104.070091,30.762619],[104.069932,30.762863],[104.06991,30.763014],[104.069878,30.763598],[104.069863,30.763674],[104.069836,30.763723],[104.069778,30.763796],[104.06972,30.763842],[104.069163,30.764093],[104.069126,30.764119],[104.069105,30.764157],[104.069108,30.764201],[104.069141,30.764239],[104.069437,30.764487],[104.069457,30.764528],[104.069463,30.764586],[104.069486,30.764671],[104.069542,30.764776],[104.069619,30.764855],[104.070225,30.765164],[104.070319,30.765182],[104.07038,30.765183],[104.070465,30.765161],[104.07054,30.7651],[104.070956,30.764634],[104.071024,30.764591],[104.071137,30.764551],[104.071289,30.764523],[104.071583,30.764511],[104.072076,30.76457],[104.072184,30.764629],[104.072272,30.764701],[104.072375,30.764821],[104.072481,30.765029],[104.072554,30.765227],[104.072573,30.765365],[104.072558,30.765498],[104.072519,30.765638],[104.071788,30.766781],[104.071611,30.767002],[104.071233,30.767547],[104.071172,30.767628],[104.071097,30.76768],[104.070989,30.767714],[104.070852,30.767741],[104.070738,30.76774],[104.070616,30.767705],[104.070522,30.767651],[104.070409,30.767546],[104.07022,30.767398],[104.070133,30.767368],[104.070018,30.767361],[104.069849,30.767395],[104.069536,30.767497],[104.06925,30.767603],[104.069522,30.76815],[104.071425,30.771969],[104.072009,30.773141],[104.072374,30.774134],[104.072666,30.775131],[104.072748,30.775411],[104.073026,30.777029],[104.073105,30.778293],[104.072957,30.779122],[104.072557,30.780212],[104.071992,30.78093],[104.071322,30.781574],[104.069522,30.782794],[104.068105,30.783584],[104.067139,30.783954],[104.066278,30.784027],[104.065756,30.783852],[104.065495,30.783543],[104.065374,30.783035],[104.065295,30.781194],[104.065139,30.780538],[104.064799,30.780214],[104.064269,30.780002],[104.063512,30.780001],[104.062738,30.780223],[104.062051,30.780693],[104.060189,30.782238],[104.059623,30.782598],[104.058197,30.78314],[104.057492,30.783547],[104.057342,30.783682],[104.056735,30.784227],[104.056326,30.784945],[104.056274,30.785342],[104.056308,30.785901],[104.056613,30.786848],[104.057144,30.787878],[104.057631,30.788363],[104.058693,30.788884],[104.059302,30.789345],[104.059928,30.790115],[104.060485,30.791069],[104.061094,30.792384],[104.061355,30.793464],[104.061468,30.794584],[104.061416,30.795637],[104.061138,30.797571],[104.061164,30.798166],[104.061399,30.798712],[104.061738,30.799197],[104.062182,30.799395],[104.062678,30.799383],[104.063165,30.79916],[104.063608,30.798728],[104.065087,30.797087],[104.065948,30.796359],[104.066922,30.7959],[104.067905,30.795691],[104.068447,30.795715],[104.068827,30.795731],[104.069644,30.795954],[104.070731,30.796526],[104.071775,30.79732],[104.072114,30.797829],[104.072297,30.798487],[104.072323,30.799243],[104.072262,30.799911],[104.072128,30.800553],[104.072053,30.800914],[104.072062,30.801448],[104.07221,30.801931],[104.072584,30.802328],[104.073245,30.80254],[104.073766,30.802547],[104.075053,30.802264],[104.075696,30.802239],[104.076322,30.8024],[104.076648,30.802529],[104.077041,30.802685],[104.077054,30.802691],[104.077069,30.802696],[104.077132,30.802721],[104.077155,30.802742],[104.077184,30.802743],[104.080477,30.804723],[104.08086,30.804893],[104.08116,30.804979],[104.081928,30.804323],[104.082245,30.804186],[104.082622,30.80412],[104.083037,30.804152],[104.083423,30.804283],[104.083782,30.804614],[104.084037,30.805152],[104.084824,30.806688],[104.085089,30.807011],[104.085384,30.807145],[104.085706,30.807159],[104.086583,30.806979],[104.087207,30.806691],[104.087649,30.806276],[104.088052,30.805801],[104.08866,30.805274],[104.089242,30.804841],[104.08953,30.804449],[104.089657,30.804118],[104.089776,30.803529],[104.089733,30.803216],[104.089561,30.802938],[104.089094,30.802483],[104.088719,30.802269],[104.088267,30.802135],[104.088052,30.802028],[104.087623,30.801642],[104.087072,30.801024],[104.08669,30.800452],[104.086327,30.79985],[104.086273,30.799314],[104.086421,30.798778],[104.086702,30.798416],[104.087185,30.798216],[104.08815,30.798163],[104.088498,30.79827],[104.088893,30.798531],[104.089406,30.799113],[104.089689,30.799702],[104.090024,30.800453],[104.090412,30.800962],[104.09115,30.80182],[104.091376,30.802048],[104.091659,30.802182],[104.092047,30.802168],[104.09235,30.802056],[104.092913,30.801735],[104.093133,30.801539],[104.093248,30.801279],[104.093507,30.8002],[104.093668,30.799436],[104.093823,30.798922],[104.093904,30.798493],[104.093856,30.79815],[104.093716,30.797863],[104.093435,30.797461],[104.093092,30.797158],[104.09231,30.79671],[104.091519,30.796348],[104.091028,30.796032],[104.090754,30.795598],[104.090643,30.795099],[104.09077,30.794435],[104.091093,30.793878],[104.091398,30.793642],[104.091918,30.79346],[104.092444,30.793468],[104.093086,30.793562],[104.093707,30.79375],[104.094144,30.794018],[104.094791,30.794447],[104.095927,30.79501],[104.096838,30.795426],[104.097636,30.795643],[104.098419,30.79575],[104.099047,30.795707],[104.099718,30.795533],[104.100321,30.795252],[104.100869,30.794796],[104.10127,30.79426],[104.101632,30.793403],[104.102003,30.792583],[104.102345,30.791822],[104.10257,30.791415],[104.102878,30.790991],[104.103347,30.790603],[104.103856,30.790375],[104.104036,30.790349],[104.104622,30.79034],[104.106376,30.788818],[104.107442,30.788162],[104.108832,30.787617],[104.110897,30.787021],[104.113022,30.786623],[104.11704,30.786149],[104.119313,30.785703],[104.120855,30.785054],[104.121144,30.784933],[104.122982,30.783741],[104.124239,30.782526],[104.125193,30.780945],[104.125697,30.779641],[104.125783,30.778527],[104.12575,30.778241],[104.125653,30.777435],[104.125342,30.776841],[104.124725,30.776186],[104.123771,30.775418],[104.117621,30.771289],[104.117144,30.770696],[104.116953,30.770039],[104.116951,30.769956],[104.116935,30.76927],[104.117212,30.768575],[104.117829,30.767832],[104.118956,30.767026],[104.120666,30.766119],[104.122071,30.765659],[104.122212,30.765639],[104.123484,30.765461],[104.125253,30.765452],[104.130033,30.765721],[104.131185,30.76572],[104.132322,30.765568],[104.13357,30.765146],[104.134722,30.764499],[104.135858,30.763718],[104.136267,30.763411],[104.137193,30.762718],[104.137826,30.761974],[104.138398,30.760871],[104.138675,30.759815],[104.138961,30.758253],[104.139127,30.756475],[104.139829,30.74897],[104.139845,30.748539],[104.13995,30.745804],[104.139889,30.745086],[104.139715,30.744267],[104.139614,30.743992],[104.139262,30.744255],[104.137214,30.743852],[104.136606,30.744297],[104.136341,30.745043],[104.136328,30.746387],[104.135626,30.747729],[104.134932,30.748099],[104.133723,30.748017],[104.132105,30.747703],[104.130154,30.747699],[104.128969,30.748439],[104.127233,30.749326],[104.126803,30.749174],[104.126117,30.748572],[104.126083,30.748427],[104.125701,30.746777],[104.125915,30.745585],[104.126002,30.745103],[104.126007,30.744786],[104.125964,30.744371],[104.125747,30.743514],[104.125704,30.743197],[104.125816,30.742906],[104.126015,30.742686],[104.128349,30.741446],[104.128384,30.741364],[104.128366,30.741266],[104.128227,30.741183],[104.127689,30.741086],[104.127429,30.741032],[104.127273,30.740894],[104.126988,30.739956],[104.126761,30.739858],[104.124819,30.740082],[104.12435,30.740067],[104.123786,30.739959],[104.122572,30.739365],[104.122157,30.739366],[104.120075,30.740349],[104.119779,30.740349],[104.119641,30.740223],[104.119701,30.74003],[104.120613,30.73938],[104.120889,30.739269],[104.121662,30.739173],[104.121904,30.739047],[104.122069,30.738716],[104.122164,30.737887],[104.12212,30.737449],[104.122103,30.737279],[104.121965,30.736906],[104.121713,30.736602],[104.121647,30.736566],[104.121409,30.736437],[104.121063,30.736381],[104.120716,30.736464],[104.120334,30.736742],[104.120234,30.736785],[104.120109,30.736838],[104.119641,30.736908],[104.118963,30.736839],[104.118694,30.736715],[104.11866,30.736452],[104.118822,30.736245],[104.119102,30.735885],[104.119197,30.73561],[104.119128,30.735319],[104.118986,30.735158],[104.118678,30.734809],[104.118512,30.734601],[104.118443,30.734418],[104.11846,30.734314],[104.118555,30.734244],[104.119371,30.734174],[104.11958,30.734107],[104.119683,30.733933],[104.1197,30.733753],[104.119597,30.73354],[104.117809,30.732339],[104.116994,30.731716],[104.116317,30.731109],[104.115327,30.73012],[104.113465,30.730841],[104.113241,30.729867],[104.112507,30.730317],[104.111009,30.729568],[104.109609,30.729168],[104.109578,30.729188],[104.109513,30.72914],[104.109361,30.728754],[104.107139,30.728874],[104.10674,30.729213],[104.106743,30.729242],[104.106709,30.72924],[104.105659,30.730134],[104.104351,30.731321],[104.103313,30.731239],[104.102715,30.730488],[104.102266,30.729416],[104.102577,30.727358],[104.102966,30.725656],[104.102989,30.724176],[104.101704,30.722897],[104.100327,30.72229],[104.096957,30.722042],[104.09272,30.721936],[104.092166,30.721723],[104.091699,30.721055],[104.091606,30.721123],[104.09147,30.721148],[104.090801,30.721078],[104.090627,30.721031],[104.090237,30.720872],[104.090117,30.720852],[104.089588,30.720913],[104.089476,30.720899],[104.089416,30.720866],[104.088899,30.72036],[104.088847,30.720275],[104.088593,30.719869],[104.088201,30.718988],[104.087982,30.716874],[104.088187,30.716056],[104.088492,30.715603],[104.088637,30.715384],[104.088745,30.714857],[104.088873,30.714227],[104.088873,30.714049],[104.088804,30.713882],[104.088621,30.713717],[104.088459,30.713678],[104.088225,30.713662],[104.086956,30.713857],[104.086235,30.713898],[104.085505,30.713856],[104.084801,30.713717],[104.082698,30.713059],[104.082446,30.713018],[104.082238,30.713072],[104.082168,30.713294],[104.082264,30.71513],[104.082255,30.715324],[104.082099,30.715504],[104.081934,30.715532],[104.080526,30.71535],[104.08003,30.715309],[104.079408,30.715301],[104.077697,30.715279],[104.077579,30.715278],[104.076997,30.715154],[104.076591,30.714966],[104.076563,30.714336],[104.076552,30.714089],[104.076466,30.713005],[104.076321,30.713116],[104.075699,30.713517],[104.075192,30.713852],[104.075164,30.71383],[104.075151,30.71382],[104.075137,30.713808],[104.074691,30.713444],[104.074681,30.713438],[104.074671,30.713428],[104.074623,30.713389],[104.074612,30.713382],[104.074602,30.713372],[104.074549,30.713329],[104.074536,30.71332],[104.074524,30.713312],[104.074152,30.713129],[104.073818,30.713098],[104.07346,30.713134],[104.072518,30.713473],[104.072207,30.713596],[104.072033,30.714507],[104.072024,30.71467],[104.07206,30.714854],[104.072127,30.714939],[104.073695,30.716598],[104.073732,30.716735],[104.073723,30.716892],[104.073631,30.717022],[104.073518,30.717072],[104.072941,30.717172],[104.072799,30.717197],[104.072746,30.717242],[104.07269,30.717593],[104.072628,30.717684],[104.07253,30.717754],[104.071992,30.717945],[104.071946,30.718004],[104.071845,30.718335],[104.071792,30.718413],[104.071731,30.718425],[104.071671,30.718399],[104.071371,30.718155],[104.071094,30.717786],[104.070908,30.717334],[104.070915,30.717162],[104.070875,30.71708],[104.070795,30.716469],[104.070826,30.716393],[104.070765,30.716242],[104.070877,30.713811],[104.070882,30.713691],[104.071053,30.712026],[104.071054,30.712021],[104.071059,30.711971],[104.071198,30.710617],[104.071221,30.710398],[104.071341,30.709973],[104.071516,30.709355],[104.070771,30.709347],[104.070731,30.708628],[104.070693,30.707936],[104.072058,30.707744],[104.072063,30.70722],[104.072084,30.70523],[104.072088,30.704913],[104.072111,30.702807],[104.072155,30.702786],[104.072154,30.702738],[104.072153,30.702704],[104.072113,30.702682],[104.072123,30.701815],[104.072133,30.700901],[104.07214,30.700249],[104.072162,30.698289],[104.072162,30.697768],[104.072381,30.697769],[104.076036,30.697781],[104.076227,30.697782],[104.07801,30.697518],[104.079906,30.697504],[104.081403,30.697493],[104.081557,30.697492],[104.087585,30.697447],[104.089931,30.697428],[104.090232,30.697426],[104.092961,30.697406],[104.092999,30.697406],[104.09225,30.696379],[104.091914,30.696721],[104.091571,30.696235],[104.091213,30.695769],[104.091149,30.695662],[104.091149,30.695555],[104.091293,30.695433],[104.093662,30.694311],[104.09378,30.694207],[104.093846,30.694091],[104.093853,30.693938],[104.093511,30.692576],[104.093424,30.692358],[104.093318,30.692194],[104.093172,30.692106],[104.092582,30.691924],[104.092349,30.691866],[104.092174,30.691771],[104.092014,30.691633],[104.09152,30.690947],[104.091468,30.690875],[104.091395,30.690759],[104.091389,30.690642],[104.091428,30.690544],[104.092171,30.690005],[104.092411,30.689779],[104.092536,30.689597],[104.092565,30.689437],[104.092513,30.689255],[104.092026,30.6886],[104.091866,30.688337],[104.091814,30.688119],[104.091851,30.687893],[104.091968,30.687668],[104.092141,30.687486],[104.092332,30.687362],[104.092536,30.687318],[104.092849,30.687296],[104.093863,30.687303],[104.092881,30.685827],[104.091902,30.684357],[104.088856,30.67978],[104.088789,30.679679],[104.088837,30.679655],[104.09164,30.678257],[104.091658,30.678248],[104.093256,30.677451],[104.093291,30.677475],[104.09329,30.677434],[104.094546,30.676807],[104.094562,30.676808],[104.094577,30.676792],[104.094711,30.676725],[104.094606,30.676596],[104.094591,30.676586],[104.094581,30.676566],[104.094166,30.676059],[104.09405,30.675939],[104.093241,30.674811],[104.091956,30.673212],[104.091382,30.672452],[104.090738,30.671655],[104.090327,30.671074],[104.090237,30.670877],[104.090205,30.670831],[104.090109,30.670769],[104.089833,30.670385],[104.089866,30.670353],[104.089813,30.670357],[104.089624,30.670093],[104.088271,30.670681],[104.087679,30.671041],[104.087139,30.671538],[104.086485,30.672304],[104.08613,30.672574],[104.08559,30.672843],[104.085065,30.672942],[104.084375,30.67295],[104.084348,30.67295],[104.083857,30.672956],[104.083246,30.67304],[104.08272,30.673267],[104.081072,30.674387],[104.078712,30.675746],[104.078315,30.675975],[104.077881,30.67611],[104.077754,30.676134],[104.077071,30.676265],[104.076602,30.676449],[104.076426,30.676551],[104.076161,30.676704],[104.075792,30.677087],[104.075252,30.677598],[104.07494,30.677793],[104.074754,30.67791],[104.074271,30.678065],[104.073347,30.678178],[104.071852,30.678275],[104.071846,30.678276],[104.071641,30.678289],[104.071029,30.678416],[104.070603,30.678614],[104.070084,30.678976],[104.069032,30.679912],[104.068619,30.680195],[104.068122,30.68045],[104.067396,30.680677],[104.066373,30.68093],[104.065647,30.681213],[104.065064,30.68151],[104.064211,30.682034],[104.063815,30.68223],[104.063694,30.68229],[104.063097,30.682463],[104.062896,30.68214],[104.062813,30.681975],[104.062765,30.681877],[104.062694,30.681777],[104.062478,30.681503],[104.062446,30.681451],[104.062422,30.68141],[104.062372,30.681279],[104.062348,30.681168],[104.062303,30.680799],[104.062239,30.680529],[104.062063,30.680009],[104.06181,30.679057],[104.061674,30.678692],[104.061487,30.678347],[104.061344,30.67821],[104.061183,30.678113],[104.060991,30.678064],[104.060825,30.678056],[104.060106,30.678172],[104.059976,30.67818],[104.059644,30.678177],[104.059468,30.678199],[104.058586,30.678354],[104.058454,30.678348],[104.05802,30.678438]],[[104.056195,30.681016],[104.055568,30.6809],[104.055589,30.680697],[104.056389,30.679401],[104.056887,30.679581],[104.057804,30.679927],[104.058974,30.680466],[104.058893,30.680614],[104.058788,30.6808],[104.058507,30.681297],[104.058378,30.681813],[104.058219,30.681778],[104.057231,30.68156],[104.056592,30.681343],[104.05625,30.681062],[104.056195,30.681016]]]],
      });
</script>

<style scoped>
.table{
    size: large;
    margin-bottom: 1em;
    font-size: 20px;
}
</style>