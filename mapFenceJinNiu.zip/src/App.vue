<template>
  <router-view />
</template>

<script setup>
</script>

<style>
* {
  margin: 0;
  padding: 0;
}

html,
body,
#app{
  width: 100%;
  height: 100%;
}
body{
  background-color: #f7f7f7;
}
</style>
